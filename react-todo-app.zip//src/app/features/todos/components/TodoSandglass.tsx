// TodoSandglass.tsx - Update to handle timeless tasks
import React from "react";
import { Todo } from "../../core/services/todoService";

interface TodoSandglassProps {
  todos: Todo[];
  title?: string;
}

const periods = [
  { label: "Morning", start: 5, end: 11 },
  { label: "Afternoon", start: 12, end: 16 },
  { label: "Evening", start: 17, end: 20 },
  { label: "Night", start: 21, end: 4 },
];

export default function TodoSandglass({
  todos,
  title = "⏳ Todo Sandglass",
}: TodoSandglassProps) {
  // Separate todos with and without time
  const todosWithTime = todos.filter(
    (todo) => todo.time && todo.time.trim() !== ""
  );
  const todosWithoutTime = todos.filter(
    (todo) => !todo.time || todo.time.trim() === ""
  );

  // Helper: check if hour belongs to period
  const inPeriod = (hour: number, periodStart: number, periodEnd: number) => {
    if (periodStart <= periodEnd)
      return hour >= periodStart && hour <= periodEnd;
    return hour >= periodStart || hour <= periodEnd;
  };

  // Group todos by period
  const groupedTodos = periods.map((period) => {
    const items = todosWithTime.filter((todo) => {
      const [hh] = todo.time!.split(":").map(Number);
      return inPeriod(hh, period.start, period.end);
    });
    return { ...period, items };
  });

  return (
    <div className="flex flex-col gap-6 p-4 bg-white rounded-lg shadow-md">
      <h2 className="text-xl font-semibold text-gray-800 text-center">
        {title}
      </h2>

      {/* Todos grouped by time period */}
      {groupedTodos.map((group) => (
        <div key={group.label} className="flex flex-col gap-2">
          <h3 className="text-lg font-medium text-gray-700">{group.label}</h3>
          <div className="flex flex-col gap-1 border-l-4 border-gray-200 pl-3">
            {group.items.length === 0 && (
              <p className="text-gray-400 italic text-sm">No tasks</p>
            )}
            {group.items.map((todo) => (
              <div
                key={todo.id}
                className={`flex justify-between items-center p-2 rounded ${
                  todo.status === "done"
                    ? "bg-gray-100 text-gray-500 line-through"
                    : "bg-blue-50 text-blue-800"
                }`}
              >
                <span>{todo.text}</span>
                <span className="text-xs font-mono">
                  {todo.time}
                  {todo.status === "done" ? " ✅" : ""}
                </span>
              </div>
            ))}
          </div>
        </div>
      ))}

      {/* Todos without time - Now it's a feature, not a bug! */}
      {todosWithoutTime.length > 0 && (
        <div className="flex flex-col gap-2 mt-4 p-3 bg-gray-50 border border-gray-200 rounded">
          <h3 className="text-lg font-medium text-gray-700">Without Time</h3>
          <p className="text-gray-600 text-sm mb-2">
            These tasks don't have a specific time and can be done anytime.
          </p>
          <div className="flex flex-col gap-1">
            {todosWithoutTime.map((todo) => (
              <div
                key={todo.id}
                className={`flex justify-between items-center p-2 rounded ${
                  todo.status === "done"
                    ? "bg-gray-100 text-gray-500 line-through"
                    : "bg-gray-50 text-gray-700"
                }`}
              >
                <span>{todo.text}</span>
                <span className="text-xs font-mono">
                  {todo.status === "done" ? " ✅" : "⏳ Anytime"}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Empty state */}
      {todos.length === 0 && (
        <div className="text-center py-4 text-gray-500">
          <p>No tasks available</p>
        </div>
      )}
    </div>
  );
}
