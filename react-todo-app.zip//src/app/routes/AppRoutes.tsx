//AppRoutes.tsx

import { Routes, Route } from "react-router-dom";
import MainLayout from "../layouts/MainLayout";
import TodosPage from "../features/todos/pages/TodosPage";

export default function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<MainLayout />}>
        <Route index element={<TodosPage />} />
      </Route>
    </Routes>
  );
}
